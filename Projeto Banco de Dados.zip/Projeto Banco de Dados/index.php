<?php
    require_once("cabecalho.html");
?>

    <h1>Sistema PHP + MySql</h1>

<?php
    require_once("rodape.html");